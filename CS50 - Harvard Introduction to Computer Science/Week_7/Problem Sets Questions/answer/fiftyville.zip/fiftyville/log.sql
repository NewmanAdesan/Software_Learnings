-- Keep a log of any SQL queries you execute as you solve the mystery.






-- understand the airports table
.schema airports
SELECT COUNT(*) FROM airports;      -- data of 12 airports
SELECT * FROM airports LIMIT 5;






-- understand the flights table
.schema flights
SELECT COUNT(*) FROM flights;      -- flights data of only 58 people on 26th-30th of july 2021
SELECT * FROM flights LIMIT 5;
SELECT DISTINCT(day) FROM flights;






-- understand the people table
.schema people
SELECT COUNT(*) FROM people;      -- data of 200 people
SELECT * FROM people LIMIT 5;






-- understand the bank account table
.schema bank_accounts
SELECT COUNT(*) FROM bank_accounts;      -- 137 people data, their bank account, when it was created
SELECT * FROM bank_accounts LIMIT 5;









-- TO FIND THE THEIF AND ACCOMPLICE, WE WILL LOOK AT FOUR SECTIONS FoR INSPECTION
-- CAR MOVEMENT, PHONE CALLS, ATM TRANSACTION, FLIGHT MOVEMENT






-- understand the bakery_security_logs table
.schema bakery_security_logs
SELECT COUNT(*) FROM bakery_security_logs;      -- 468 data of 140 cars from 25th-31th of july 2021 (both entrance & exit data)
SELECT * FROM bakery_security_logs LIMIT 5;     -- each car may enter/exit two or more times, unfortunately we dont have data of how many times each plate number entered the building, we may not need this data anyways

SELECT DISTINCT(year) FROM bakery_security_logs;
SELECT DISTINCT(month) FROM bakery_security_logs;
SELECT DISTINCT(day) FROM bakery_security_logs;
SELECT DISTINCT(activity) FROM bakery_security_logs;
SELECT COUNT(DISTINCT(license_plate)) FROM bakery_security_logs;






-- understand the phone_calls table
.schema phone_calls
SELECT COUNT(*) FROM phone_calls;      -- 518 call data from 25th-31th of july 2021
SELECT * FROM phone_calls LIMIT 5;     -- data comprises of 172 people, their sent calls and their received calls, the exact time

SELECT DISTINCT(year) FROM phone_calls;
SELECT DISTINCT(month) FROM phone_calls;
SELECT DISTINCT(day) FROM phone_calls;
SELECT COUNT(DISTINCT(caller)) FROM phone_calls;
SELECT COUNT(DISTINCT(receiver)) FROM phone_calls;
SELECT COUNT(DISTINCT(caller)) FROM phone_calls WHERE caller IN (SELECT DISTINCT(receiver) FROM phone_calls );






-- understand the atm_transactions table
.schema atm_transactions
SELECT COUNT(*) FROM atm_transactions;      -- 1332 atm transaction data from 25th-1th of july/aug 2021 (deposit & withdraw)
SELECT * FROM atm_transactions LIMIT 5;     -- data comprises of 137 people transaction, from five different atm locations
                                            -- Humphrey Lane, Daboin Sanchez Drive, Carvalho Road, Leggett Street, Blumberg Boulevard
SELECT DISTINCT(year) FROM atm_transactions;
SELECT DISTINCT(month) FROM atm_transactions;
SELECT DISTINCT(day) FROM atm_transactions;
SELECT DISTINCT(transaction_type) FROM atm_transactions;
SELECT COUNT(DISTINCT(atm_location)) FROM atm_transactions;
SELECT COUNT(DISTINCT(account_number)) FROM atm_transactions;






-- understand the passenger table
.schema passengers
SELECT COUNT(*) FROM passengers;      -- this data links people to the flight they took via their passport_number and flight_id
SELECT * FROM passengers LIMIT 5;     -- 359 flight data of 148 people. this totals the data of 58 different flights

SELECT COUNT(DISTINCT(passport_number)) FROM passengers;






-- LETS START THINKING FROM WHERE THE CRIME STARTED
-- LETS UNDERSTAND THE CRIME SCENE REPORT TABLE AND THE INTERVIEW TABLE






-- understand the crime scene report table
.schema crime_scene_reports
SELECT COUNT(*) FROM crime_scene_reports;      -- 301 crime report data from JAN 1st 2021 - AUG 1st 2021, from 23 different streets
SELECT * FROM crime_scene_reports LIMIT 5;     -- this data consists of 7 different crimes: BANK ROBBERY, BURGLARY, CREDIT CARD FRAUD,
                                                -- EXPIRED PARKING METER, FORGERY, INSIDER TRADING, JAYWALKING
SELECT DISTINCT(year) FROM crime_scene_reports;
SELECT DISTINCT(month) FROM crime_scene_reports;
SELECT DISTINCT(day) FROM crime_scene_reports;
SELECT DISTINCT(street) FROM crime_scene_reports;
SELECT day FROM crime_scene_reports WHERE month = "8";







-- understand the interviews table
.schema interviews
SELECT COUNT(*) FROM interviews;      -- 192 interview data of 188 people of crimes that happened btw JAN 2021 & AUG 2021
SELECT * FROM interviews LIMIT 5;     --
                                                --
SELECT DISTINCT(year) FROM interviews;
SELECT DISTINCT(month) FROM interviews;
SELECT DISTINCT(day) FROM interviews;







-- SINCE WE UNDERSTAND ALL THE TABLES, LETS LOOK AT THE PROBLEM STATEMENT AND START THINKING FROM THERE
-- * CS50 RUBBER DUCK WAS STOLEN
-- * AUTHORITIES BELIEVE:
--     shortly after the theif stole the duck, the theif took a flight out of town
--     someone helped him take that flight, he had an accomplice
-- * THEFT TOOK PLACE JULY 28, 2021
-- * THEFT TOOK PLACE ON HUMPHERY STREET









-- using the crime_scene_reports table, we will only look at crimes involving: burglary, jaywalking, expired parking meter
-- but first lets look at crime_scene_reports on the 28th, 29th & 30th of july 2021
SELECT *  FROM crime_scene_reports WHERE day IN (28, 29, 30) AND street ="Humphrey Street"
-- data at id 295, 28th July is what we need, and what we will look into
-- 295 | 2021 | 7 | 28 | Humphrey Street | Theft of the CS50 duck took place at 10:15am at the Humphrey Street bakery.
-- Interviews were conducted today with three witnesses who were present at the time – each of their interview transcripts mentions the bakery.

-- from this we have two interesting information,
-- the exact time the theft took place
-- interviews related to the incident










-- Let's find the three witness from the interview table & view their transcript of the incident
SELECT * from interviews WHERE transcript LIKE "%bakery%";
-- as id 161, 162, 163, we find the three people who were interview. let see what they said
-- Ruth:
--    Sometime within ten minutes of the theft, I saw the thief get into a car in the bakery parking lot and drive away.
--    If you have security footage from the bakery parking lot,
--    you might want to look for cars that left the parking lot in that time frame.

-- Eugene:
--  - I don't know the thief's name, but it was someone I recognized.
--  - Earlier this morning, before I arrived at Emma's bakery,
--  - I was walking by the ATM on Leggett Street and saw the thief there withdrawing some money.

-- Raymond:
--  - as the thief was leaving the bakery, they called someone who talked to them for LESS THAN A MINUTE.
--  - In the call, I heard the thief say that they were planning to TAKE THE EARLIEST FLIGHT OUT of Fiftyville tomorrow.
--  - The thief then ASKED THE PERSON on the other end of the phone TO PURCHASE THE FLIGHT TICKET.





-- From Ruth's transcript, we will querry the bakery_security_logs table
-- what cars drove away within 10 minutes after 10:15am of 28 JULY 2021
SELECT * FROM bakery_security_logs WHERE day = 28 AND hour = 10 AND minute BETWEEN 15 AND 35;
-- nice, based on Ruth's transcript, we have 8 suspect. we will stream line this using Eugene's transcript
-- minute | activity | license_plate
-- 16 | exit | 5P2BI95
-- 18 | exit | 94KL13X
-- 18 | exit | 6P58WS2
-- 19 | exit | 4328GD8
-- 20 | exit | G412CB7
-- 21 | exit | L93JTIZ
-- 23 | exit | 322W7JE
-- 23 | exit | 0NTHK55










-- From Eugene's transcript, the theif withdrew money from the atm at Leggett Stree, earler in the morning
-- let's view the data of people that withdrew within this time frame
SELECT * FROM atm_transactions WHERE day = 28 AND atm_location = "Leggett Street" AND transaction_type = "withdraw";
-- nice, we have 8 suspects; we have their account number
-- account_number | amount
-- 28500762 | 48
-- 28296815 | 20
-- 76054385 | 60
-- 49610011 | 50
-- 16153065 | 80
-- 25506511 | 20
-- 81061156 | 30
-- 26013199 | 35










-- we will combine what we learnt from eugene's transcript and what we learnt from ruth's transcript
-- from ruth's, we have plate number of 8 suspects
-- from eugene's, we have the account number of 8 suspects
-- what we want to know is how many suspects do we have all together
-- we can do this in one querry, but first let take it one by one
-- let's get the name, license plate of the account numbers we got from eugene transcript
-- let's get the name of the license plates of suspects we got from ruth transcript
-- finally, we will get the id, name where the license plate of eugene transcript is in the license plate of ruth transcipt;
--  pretty simple, let's do it

-- FIRSTLY
-- get details of 8 suspects from eugene's transcript
SELECT people.name, people.license_plate, bank_accounts.account_number FROM people, bank_accounts, atm_transactions
WHERE people.id = bank_accounts.person_id
AND bank_accounts.account_number = atm_transactions.account_number
AND atm_transactions.day = 28
AND atm_transactions.atm_location = "Leggett Street" 
AND atm_transactions.transaction_type = "withdraw";
-----------------------------------------
-- name | license_plate | account_number
-- Bruce | 94KL13X | 49610011
-- Diana | 322W7JE | 26013199
-- Brooke | QX4YZN3 | 16153065
-- Kenny | 30G67EN | 28296815
-- Iman | L93JTIZ | 25506511
-- Luca | 4328GD8 | 28500762
-- Taylor | 1106N58 | 76054385
-- Benista | 8X428L0 | 81061156
-----------------------------------------


-- SECONDLY
-- get details of 9 suspects from ruths's transcript
SELECT people.name, people.license_plate, bank_accounts.account_number FROM people, bank_accounts, bakery_security_logs
WHERE people.id = bank_accounts.person_id
AND people.license_plate = bakery_security_logs.license_plate
AND bakery_security_logs.day = 28 
AND bakery_security_logs.hour = 10 
AND bakery_security_logs.minute BETWEEN 15 AND 35;
-----------------------------------------
-- name | license_plate | account_number
-- Bruce | 94KL13X | 49610011
-- Diana | 322W7JE | 26013199
-- Iman | L93JTIZ | 25506511
-- Luca | 4328GD8 | 28500762
-- Taylor | 1106N58 | 76054385
-- Barry | 6P58WS2 | 56171033
-----------------------------------------
-- notice something very interesting here, very very interesting
-- we are expecting 9 details, but this querry is giving us 6 details, what is going on
-- do we have a wrong understanding somewhere, NO, you see
-- the bank account table, doesn't have the bank account detail of all persons in the people table
-- remember, when we were understanding the bank account table, it has only 137 people's data out of 200
-- so it stands to point out that probably 3 of 9 suspect, we do not have their bank detail
-- lets assume they did not open a bank, therefore it is not possible for them to have withdrawn
-- eliminating those 3 suspects out of the 9. PERIOD
-- to show further our theory is correct, lets combine the people, bakery_security_logs table
-- and obtain the details of the 9 people


SELECT people.name, people.license_plate FROM people, bakery_security_logs
WHERE people.license_plate = bakery_security_logs.license_plate
AND bakery_security_logs.day = 28 
AND bakery_security_logs.hour = 10 
AND bakery_security_logs.minute BETWEEN 15 AND 35;
-- 221103 | Vanessa | 5P2BI95
-- 686048 | Bruce | 94KL13X
-- 243696 | Barry | 6P58WS2
-- 467400 | Luca | 4328GD8
-- 398010 | Sofia | G412CB7
-- 396669 | Iman | L93JTIZ
-- 514354 | Diana | 322W7JE
-- 560886 | Kelsey | 0NTHK55
-- 449774 | Taylor | 1106N58
-- i can bet it with you, we do not have the account details 
-- in the bank account table of Vanessa, Sofia, Kelsey
SELECT * FROM bank_accounts WHERE person_id IN ("221103", "398010", "560886");
-- and we are right, because nothing shows up. PERIOD


-- Finally the querry we actually want
-- we will get the details of people where the license plate of suspects in eugene transcript 
-- is in the license plate of suspect in ruth transcipt;
-- we can use the IN keyword or join tables to gether and look at people's details who fulfull all conditions 
SELECT people.name, people.license_plate, bank_accounts.account_number FROM people, bank_accounts, atm_transactions, bakery_security_logs
WHERE people.id = bank_accounts.person_id
AND bank_accounts.account_number = atm_transactions.account_number
AND people.license_plate = bakery_security_logs.license_plate
AND atm_transactions.day = 28
AND atm_transactions.atm_location = "Leggett Street" 
AND atm_transactions.transaction_type = "withdraw"
AND bakery_security_logs.day = 28 
AND bakery_security_logs.hour = 10 
AND bakery_security_logs.minute BETWEEN 15 AND 25;
---------------------------------------------------------
-- name | license_plate | account_number
-- Bruce | 94KL13X | 49610011
-- Diana | 322W7JE | 26013199
-- Iman | L93JTIZ | 25506511
-- Luca | 4328GD8 | 28500762
---------------------------------------------------------
-- interesting enough, it has been reduced to 4 suspects









-- From Raymond's transcript, we will querry the phone_calls table
-- lets look at calls within 10 minutes after 10:15am of 28 JULY 2021
-- and the call lasted for less than a minute, 60 seconds
SELECT caller FROM phone_calls
WHERE day = 28
AND duration < 60;
------------------------------------------
-- caller
-- (130) 555-0289
-- (499) 555-9472
-- (367) 555-5533
-- (499) 555-9472
-- (286) 555-6063
-- (770) 555-1861
-- (031) 555-6622
-- (826) 555-1652
-- (338) 555-6650
------------------------------------------


-- now we have the phone numbers of 9 suspects
-- let's check if they belong to any of our 4 suspects from engene's & ruth's transcript
-- let's see the names that corresponds to this 9 suspects
SELECT name, license_plate, phone_number, passport_number FROM people
WHERE phone_number IN (SELECT caller FROM phone_calls WHERE day = 28 AND duration < 60)
AND name IN ("Bruce", "Diana", "Iman", "Taylor", "Luca");
-----------------------------------------------------------
-- name | license_plate | phone_number | passport_number
-- Diana | 322W7JE | (770) 555-1861 | 3592750733
-- Bruce | 94KL13X | (367) 555-5533 | 5773159633
-----------------------------------------------------------
-- we now have it all down to 2 major suspect







-- From Raymond's transcript, the theif will be travelling the next day
-- let's check, out of those three suspect, via their passport_number, who travelled VERY EARLY the next day
-- we will use the flights and passengers table
-- what filghts flew at 29 july 2021? 
-- did our two suspects take any of this flights?
-- at what hour of the day did they take the flight?
-- the person who took his/her flight early in the morning is the culprit 
SELECT passengers.passport_number, passengers.seat, flights.id, flights.origin_airport_id, flights.destination_airport_id, flights.day, flights.hour, flights.minute
FROM passengers, flights
WHERE flights.id = passengers.flight_id
AND flights.day = 29
AND passengers.passport_number IN (3592750733, 5773159633);
---------------------------------------
-- passport_number | seat | id | origin_airport_id | destination_airport_id | day | hour | minute
-- 3592750733 | 4C | 18 | 8 | 6 | 29 | 16 | 0
-- 5773159633 | 4A | 36 | 8 | 4 | 29 | 8 | 20
----------------------------------------
-- this is very interesting, we are now down to 1 suspect because 
-- he/she left as early as 8:20am whilst the last suspect left 4:00pm.
-- this is the theif










-- Get the full details of the theif
SELECT name, phone_number, passport_number, license_plate, account_number
FROM people, bank_accounts
WHERE people.id = bank_accounts.person_id
AND people.passport_number = 5773159633;
----------------------------------------------------------------------------
-- name | phone_number | passport_number | license_plate | account_number
-- Bruce | (367) 555-5533 | 5773159633 | 94KL13X | 49610011
----------------------------------------------------------------------------
-- BRUCE is the THEIF





-- Where did he go to
SELECT flights.origin_airport_id, flights.destination_airport_id
FROM passengers, flights
WHERE flights.id = passengers.flight_id
AND flights.day = 29
AND passengers.passport_number = 5773159633;
--------------------------------------------
-- origin_airport_id | destination_airport_id
-- 8 | 4
--------------------------------------------

SELECT * FROM airports WHERE id IN (8, 4);
-----------------------------------------------------
-- id | abbreviation | full_name | city
-- 4 | LGA | LaGuardia Airport | New York City
-- 8 | CSF | Fiftyville Regional Airport | Fiftyville
-----------------------------------------------------

-- BRUCE left FIFTYVILLE to NEW YORK CITY 











-- WHO WAS BRUCE ACCOMPLICE
-- what phone number did bruce call
SELECT caller, receiver FROM phone_calls
WHERE day = 28
AND duration < 60
AND caller = "(367) 555-5533";
----------------------------------
-- caller | receiver
-- (367) 555-5533 | (375) 555-8161
---------------------------------







-- The person with that phone number is the accomplice
-- get the full details of the person with that phone number
SELECT name, phone_number, passport_number, license_plate, account_number
FROM people, bank_accounts
WHERE people.id = bank_accounts.person_id
AND people.phone_number = "(375) 555-8161";
-----------------------------------------------------------------------
-- name | phone_number | passport_number | license_plate | account_number
-- Robin | (375) 555-8161 |  | 4V16VO0 | 94751264
----------------------------------------------------------------------





-- ANSWERS
-- BRUCE is the theif
-- ROBIN is the accomplice
-- BRUCE fled to NEW YORK CITY



















